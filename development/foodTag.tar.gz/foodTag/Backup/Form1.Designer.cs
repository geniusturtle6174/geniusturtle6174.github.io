﻿namespace foodTag
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.檔案ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.讀取文字檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.結束程式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.儲存文字檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.說明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.關閉文字檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.標記為食物ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.標記為店名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.標記為口味ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.取消標記ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.White;
            this.richTextBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.richTextBox1.DetectUrls = false;
            this.richTextBox1.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.richTextBox1.HideSelection = false;
            this.richTextBox1.Location = new System.Drawing.Point(12, 27);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(930, 495);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.SelectionChanged += new System.EventHandler(this.richTextBox1_SelectionChanged);
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStrip1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.檔案ToolStripMenuItem,
            this.說明ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(954, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 檔案ToolStripMenuItem
            // 
            this.檔案ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.讀取文字檔ToolStripMenuItem,
            this.儲存文字檔ToolStripMenuItem,
            this.關閉文字檔ToolStripMenuItem,
            this.toolStripSeparator1,
            this.結束程式ToolStripMenuItem});
            this.檔案ToolStripMenuItem.Name = "檔案ToolStripMenuItem";
            this.檔案ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.檔案ToolStripMenuItem.Text = "檔案";
            this.檔案ToolStripMenuItem.Click += new System.EventHandler(this.檔案ToolStripMenuItem_Click);
            // 
            // 讀取文字檔ToolStripMenuItem
            // 
            this.讀取文字檔ToolStripMenuItem.Name = "讀取文字檔ToolStripMenuItem";
            this.讀取文字檔ToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.讀取文字檔ToolStripMenuItem.Text = "讀取文字檔";
            this.讀取文字檔ToolStripMenuItem.Click += new System.EventHandler(this.讀取文字檔ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(153, 6);
            // 
            // 結束程式ToolStripMenuItem
            // 
            this.結束程式ToolStripMenuItem.Name = "結束程式ToolStripMenuItem";
            this.結束程式ToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.結束程式ToolStripMenuItem.Text = "結束程式";
            this.結束程式ToolStripMenuItem.Click += new System.EventHandler(this.結束程式ToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // 儲存文字檔ToolStripMenuItem
            // 
            this.儲存文字檔ToolStripMenuItem.Name = "儲存文字檔ToolStripMenuItem";
            this.儲存文字檔ToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.儲存文字檔ToolStripMenuItem.Text = "儲存文字檔";
            this.儲存文字檔ToolStripMenuItem.Click += new System.EventHandler(this.儲存文字檔ToolStripMenuItem_Click);
            // 
            // 說明ToolStripMenuItem
            // 
            this.說明ToolStripMenuItem.Name = "說明ToolStripMenuItem";
            this.說明ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.說明ToolStripMenuItem.Text = "說明";
            this.說明ToolStripMenuItem.Click += new System.EventHandler(this.說明ToolStripMenuItem_Click);
            // 
            // 關閉文字檔ToolStripMenuItem
            // 
            this.關閉文字檔ToolStripMenuItem.Name = "關閉文字檔ToolStripMenuItem";
            this.關閉文字檔ToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.關閉文字檔ToolStripMenuItem.Text = "關閉文字檔";
            this.關閉文字檔ToolStripMenuItem.Click += new System.EventHandler(this.關閉文字檔ToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.標記為食物ToolStripMenuItem,
            this.標記為店名ToolStripMenuItem,
            this.標記為口味ToolStripMenuItem,
            this.toolStripSeparator2,
            this.取消標記ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.contextMenuStrip1.Size = new System.Drawing.Size(141, 98);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // 標記為食物ToolStripMenuItem
            // 
            this.標記為食物ToolStripMenuItem.Name = "標記為食物ToolStripMenuItem";
            this.標記為食物ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.標記為食物ToolStripMenuItem.Text = "標記為\"食物\"";
            this.標記為食物ToolStripMenuItem.Click += new System.EventHandler(this.標記為食物ToolStripMenuItem_Click);
            // 
            // 標記為店名ToolStripMenuItem
            // 
            this.標記為店名ToolStripMenuItem.Name = "標記為店名ToolStripMenuItem";
            this.標記為店名ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.標記為店名ToolStripMenuItem.Text = "標記為\"店名\"";
            this.標記為店名ToolStripMenuItem.Click += new System.EventHandler(this.標記為店名ToolStripMenuItem_Click);
            // 
            // 標記為口味ToolStripMenuItem
            // 
            this.標記為口味ToolStripMenuItem.Name = "標記為口味ToolStripMenuItem";
            this.標記為口味ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.標記為口味ToolStripMenuItem.Text = "標記為\"口味\"";
            this.標記為口味ToolStripMenuItem.Click += new System.EventHandler(this.標記為口味ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // 取消標記ToolStripMenuItem
            // 
            this.取消標記ToolStripMenuItem.Name = "取消標記ToolStripMenuItem";
            this.取消標記ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.取消標記ToolStripMenuItem.Text = "取消標記";
            this.取消標記ToolStripMenuItem.Click += new System.EventHandler(this.取消標記ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 534);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "食記標註程式(請用滑鼠右鍵標記)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 檔案ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 讀取文字檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 結束程式ToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem 儲存文字檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 說明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 關閉文字檔ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 標記為食物ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 標記為店名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 標記為口味ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 取消標記ToolStripMenuItem;
    }
}

