﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace foodTag
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string left = "([{";
        string right = ")]}";
        string nowFile = "";

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            //
        }

        private void richTextBox1_SelectionChanged(object sender, EventArgs e)
        {
            //
        }

        private void 結束程式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void 讀取文字檔ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                nowFile = dlg.FileName;
                StreamReader sr = new StreamReader(dlg.FileName, Encoding.Default);
                richTextBox1.Text = sr.ReadToEnd();
                sr.Close();

                讀取文字檔ToolStripMenuItem.Enabled = false;
                儲存文字檔ToolStripMenuItem.Enabled = true;
                關閉文字檔ToolStripMenuItem.Enabled = true;
            }
            else {
                // do nothing
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            //
        }

        private void 檔案ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
        }

        private void 說明ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = "- 各種標記，目前要改動的話，必須重編程式\n" +
                         "  因為應該只用這一次所以就不寫的很彈性了\n" +
                         "- 流程：開檔→編輯→儲存→關閉。\n";
            MessageBox.Show(str, "說明",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void 儲存文字檔ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter(nowFile,false,Encoding.Default);
            sw.Write(richTextBox1.Text);
            sw.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            讀取文字檔ToolStripMenuItem.Enabled = true;
            儲存文字檔ToolStripMenuItem.Enabled = false;
            關閉文字檔ToolStripMenuItem.Enabled = false;
        }

        private void 關閉文字檔ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            nowFile = "";
            
            讀取文字檔ToolStripMenuItem.Enabled = true;
            儲存文字檔ToolStripMenuItem.Enabled = false;
            關閉文字檔ToolStripMenuItem.Enabled = false;
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void markAs(string type) {
            switch (type) { 
                case "食物":
                    if (richTextBox1.SelectedText == "") { return; }
                    richTextBox1.SelectedText = left[0] + richTextBox1.SelectedText + right[0];
                    break;
                case "店名":
                    if (richTextBox1.SelectedText == "") { return; }
                    richTextBox1.SelectedText = left[1] + richTextBox1.SelectedText + right[1];
                    break;
                case "口味":
                    if (richTextBox1.SelectedText == "") { return; }
                    richTextBox1.SelectedText = left[2] + richTextBox1.SelectedText + right[2];
                    break;
                case "取消":
                    string temp = richTextBox1.SelectedText;
                    temp = temp.TrimStart(left.ToCharArray());
                    temp = temp.TrimEnd(right.ToCharArray());
                    richTextBox1.SelectedText = temp;
                    break;
            }
        }

        private void 標記為食物ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            markAs("食物");
        }

        private void 標記為店名ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            markAs("店名");
        }

        private void 標記為口味ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            markAs("口味");
        }

        private void 取消標記ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            markAs("取消");
        }
    }
}